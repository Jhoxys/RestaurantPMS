﻿namespace RestaurantPMS.Models
{
    public class Base
    {
        public int Key { get; set; }
        public string? Value { get; set; }
    }
}
