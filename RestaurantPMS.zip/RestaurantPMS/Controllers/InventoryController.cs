﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantPMS.Models;
using RestaurantPMS.Repository;
using RestaurantPMS.Service;
using RestaurantPMS.ViewModels; // <-- 1. ViewModel (InventarioViewModel)
using System.Collections.Generic;
using System.Linq;
using X.PagedList;              // <-- 3. Paginación
using X.PagedList.Extensions;

namespace RestaurantPMS.Controllers
{
    public class InventoryController : Controller
    {
        private readonly RestauranteRepository _repo;

        public InventoryController(DapperContext context, RestauranteRepository repo)
        {
            _repo = repo;
        }

        // =========================================================================
        // MÉTODO GET: Index (Carga la página principal del Inventario)
        // =========================================================================
        public IActionResult Index(int? page)
        {
            var pageNumber = page ?? 1;
            var pageSize = 8;

            // 1. Obtener TODOS los datos del repositorio en una sola llamada DTO
            // NOTA: Asumo que tienes un método _repo.GetInventoryData() que devuelve el DTO
            var inventoryData = _repo.GetInventoryTemp();
            var cat = _repo.GetCategories();
            var pro = _repo.GetProviders();

            // Si el DTO o la lista de productos es nula, inicializar con listas vacías
            var products = inventoryData.ToList() ?? new List<ProductoMov>();
            var category = cat.ToList() ?? new List<Base>();
            var prov = pro.ToList() ?? new List<Base>();

            // 2. Aplicar la paginación a la lista de productos
            var dataPaginated = products.ToPagedList(pageNumber, pageSize);

            // 3. Construir y Devolver el ViewModel
            var viewModel = new InventarioViewModel
            {
                ProductosInventarioMov = dataPaginated,
                // Mapeamos las listas Base (Key/Value) directamente del DTO al ViewModel
                CategoriasDisponibles = cat,
                ProveedoresDisponibles = pro,
                NuevoProducto = new AgregarProductoModel() // Inicializa el modelo del formulario vacío
            };

            return View(viewModel);
        }

        // =========================================================================
        // MÉTODO POST: AgregarItem (Maneja el envío del formulario)
        // =========================================================================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AgregarItem(AgregarProductoModel nuevoProducto)
        {
            nuevoProducto.TransactionNumber = string.IsNullOrWhiteSpace(nuevoProducto.TransactionNumber)
           ? "N/A"
           : nuevoProducto.TransactionNumber;
            nuevoProducto.ProveedorId = 1;
            // 1. Verificar la validación de datos
            if (!ModelState.IsValid)
            {
                var pageNumber = 1;
                var pageSize = 8;

                // 1. Obtener TODOS los datos del repositorio en una sola llamada DTO
                // NOTA: Asumo que tienes un método _repo.GetInventoryData() que devuelve el DTO
                var inventoryData = _repo.GetInventoryTemp();
                var cat = _repo.GetCategories();
                var pro = _repo.GetProviders();

                // Si el DTO o la lista de productos es nula, inicializar con listas vacías
                var products = inventoryData.ToList() ?? new List<ProductoMov>();
                var category = cat.ToList() ?? new List<Base>();
                var prov = pro.ToList() ?? new List<Base>();

                // 2. Aplicar la paginación a la lista de productos
                var dataPaginated = products.ToPagedList(pageNumber, pageSize);

                // 3. Construir y Devolver el ViewModel
                var viewModel = new InventarioViewModel
                {
                    ProductosInventarioMov = dataPaginated,
                    // Mapeamos las listas Base (Key/Value) directamente del DTO al ViewModel
                    CategoriasDisponibles = cat,
                    ProveedoresDisponibles = pro,
                    NuevoProducto = new AgregarProductoModel() // Inicializa el modelo del formulario vacío
                };

                return View("Index", viewModel);
            }

            // 2. Si la validación es exitosa: Guardar en la DB
            _repo.InsertProductMovement(new ProductoMov
            {
                TransactionNumber = nuevoProducto.TransactionNumber,
                ProductoId = 1,
                Nombre = nuevoProducto.Nombre_Producto,
                UnidadMedida = nuevoProducto.Unidad,
                CostoUnitario = nuevoProducto.Costo_Unitario,
                StockActual = nuevoProducto.Stock_Actual,
                CategoryId = nuevoProducto.CategoriaId,
                ProvaiderId = nuevoProducto.ProveedorId,
                StokMin = nuevoProducto.Stock_Minimo,
                Estatus = "TRANSITO"
            });

            // 3. Redirigir al Index (patrón PRG)
            return RedirectToAction("Index");
        }
    }
}